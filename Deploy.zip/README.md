Initial Install:
   Run INSTALL.bat, leaving all the options that come up as default
   The command window will disappear when the installation is completed

Operation:
   Run START.bat to start the program
   
   Games are stored in the games folder
   Individual results are stored in the results folder
   The generated csv file is games.csv